<!DOCTYPE html>
<html lang="en">
<head>

<?php 
	include ('header.php');
	if(isset($_SESSION["Account"]))
  		echo "<script>history.back();</script>";

?>

<?php include('style.css');?>
    </head>
    <body>
    
     
     <div>
     <form action="controller/user_login.php" method="post">
  <div align="center">
  <br /><br /><br />
  帳號 :
  <input type="text" name="Account" id="Account" /><br /><br />
    密碼 :
  <input type="password" name="Password" id="Password" /><br /><br />
  <input type="submit" value="登入" style="font-size:24px; font-family:'微軟正黑體'" />
  <input type="button" value="註冊" onclick="javascript:location.href='Register.php'" style="font-size:24px; font-family:'微軟正黑體'" /><br /><br />
  </div>
  
  <?php	
  if(isset($_GET["request"]))
  	echo "<script>alert(\"你輸入的帳號或密碼不正確，請重新輸入\")</script>";
  ?>

</form>
     </div> 
      
    <?php
	include('footer.php');
	?>

      
   </body>
</html>