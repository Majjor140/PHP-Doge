<?php
include('style.css');
?>
<footer>
        <div>© 2022 CTM</divs>
    </footer>