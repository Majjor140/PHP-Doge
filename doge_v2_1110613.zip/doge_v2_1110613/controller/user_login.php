<?php
include("connectDB.php");
session_start();

if(isset($_SESSION["Account"])){
	$Match=true;
}else if(isset($_POST["Account"])){
	$MemberName=$_POST["Account"];
	$MemberAccount=$_POST["Account"];
	$MemberPassword=$_POST["Password"];
	
	
	$sql_query="SELECT * FROM `user`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Account"]==$MemberAccount&&$row_result["Password"]==$MemberPassword){
			$_SESSION["Account"]=$MemberAccount;
			$_SESSION["ID"]=$row_result["ID"];
		/*$_SESSION["PhotoProfile"]=$row_result["PhotoProfile"];
		$_SESSION["Email"]=$row_result["E-mail"];
		$_SESSION["Phone_Number"]=$row_result["Phone_Number"];
		$_SESSION["Address"]=$row_result["Address"];
		$_SESSION["PreE-mail"]=$row_result["PreE-mail"];
		$_SESSION["Sort"]=$row_result["Sort"];
		$_SESSION["Status"]=$row_result["Status"];*/
		$match = true;
		}
	}	
	if($match)
		header("location:../index.php");
	else
		header("location:../login.php?request=Wrong");
}
?>