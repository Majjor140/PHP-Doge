<?php 
	include ('style.css');
?>
<nav>
         <label class="logo">浪我來養</label>
         <ul>
            <li><a class="active" href="index.php">首頁</a></li>
            <li>
               <a href="upload.php">動物管理區
               <i class="fas fa-caret-down"></i>
               </a>
            </li>
            <li>
               <a href="user.php">帳號管理員
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
               <li><a href="user.php">◎使用者帳號</a></li>
               <li><a href="adobt_form.php">◎領養申請列表</a></li>
               </ul>
            </li>
            <li><a href="../index.php">前端</a></li>
         </ul>
      </nav>