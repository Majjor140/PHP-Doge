<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="dog.css">
</head>
    <body>
    <?php 
	include ('header.php');
	?>
    <?php 
	include ('body.php');
	?>             
    <?php
	include('footer.php');
	?>

      
   </body>
</html>