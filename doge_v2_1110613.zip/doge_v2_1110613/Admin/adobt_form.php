<!DOCTYPE html>
<html lang="en">

<head>
<style>
.coolscrollbar{scrollbar-arrow-color:yellow;scrollbar-base-color:lightsalmon;}
</style>
    </head>
    <body>
    <?php 
	include("controller/connectDB.php");
	include ('header.php');
	?>

	<div style="overflow:auto">
	<table border="1" style="overflow:auto" >
	<?php
	$i=0;
	$column=array("ID","userID","petID","Sendtime","Operation");
	echo "<tr>";
	for($i;$i<sizeof($column)-1;$i++){
		echo "<td>".$column[$i]."</td>";
	}
	echo "<td colspan=\"2\">".$column[sizeof($column)-1]."</td>";
	echo "</tr>";
	?>
    
    <?php
	
	
	$sql_query="SELECT * FROM `applicationform`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_row($result)){
		echo "<tr>";
		for($i=0;$i<sizeof($row_result);$i++)
			echo "<td>".$row_result[$i]."</td>";
		
			
		echo "<td><input type=\"button\" value=\"刪除\" onclick=\"javascript:location.href='controller/deleteuser.php?id=$row_result[0]'\" style=\"font-size:24px; font-family:'微軟正黑體'\" /></td>";
		
		echo "<td><input type=\"button\" value=\"核准\" onclick=\"javascript:location.href='controller/checkuser.php?id=$row_result[0]'\" style=\"font-size:24px; font-family:'微軟正黑體'\" /></td>";
		echo "</tr>";
	}
	?>
    </table>
    </div>
      
    <?php
	include('footer.php');
	?>

      
   </body>
</html>