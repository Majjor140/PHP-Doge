<!DOCTYPE html>
<html lang="en">
<head>
    </head>
    <body>
    
    <?php 
	include ('header.php');
	include ('style.css');
	?>
    <div class="allbox">
		<div class="wrap">
			<div class="box lg md">
				<div class="contentBox">
					<h1>動物管理區</h1>
				</div>
				<div class="imgBox">
					<img src="" alt="">
				</div>
				<div class="contentBox">
					<p>上傳寵物資料</p>
				<a href="upload.php">進入</a>
		</div>
	</div>
    
    <div class="allbox">
		<div class="wrap">
			<div class="box lg md">
				<div class="contentBox">
					<h1>帳號管理區</h1>
				</div>
				<div class="imgBox">
					<img src="" alt="">
				</div>
				<div class="contentBox">
					<p>管理使用者資料</p>
				<a href="user.php">進入</a>
		</div>
	</div>
    
    <div class="allbox">
		<div class="wrap">
			<div class="box lg md">
				<div class="contentBox">
					<h1>回到前端</h1>
				</div>
				<div class="imgBox">
					<img src="" alt="">
				</div>
				<div class="contentBox">
					<p>前往前端畫面</p>
				<a href="../index.php">進入</a>
		</div>
	</div>
      
    <?php
	include('footer.php');
	?>

      
   </body>
</html>